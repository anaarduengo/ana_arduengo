package com.example.n2w2;

import android.util.EventLog;

import com.example.ntw.EventItem;

import java.io.Serializable;
import java.util.Date;

public class ItemList implements Serializable {
    private com.example.ntw.EventItem[] A;
    int i;

    public ItemList() {
        A = new EventItem[100];
        i = 0;
    }

    public void Insert(EventItem q) {
        if(i < 100) {
            A[i] = q;
            ++i;
        }
    }

    public EventItem Acces(int j) {
        return A[j];
    }

    public int size() {
        return i + 1;
    }
}
