package com.example.n2w2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;

import java.util.Calendar;

public class Main4Activity extends AppCompatActivity {

    private Calendar selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        selectedDate = Calendar.getInstance();

        //BUTTON UPDATE

        final Button confirmButton = findViewById(R.id.confirmButton);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                com.example.ntw.EventItem item = new com.example.ntw.EventItem("-",selectedDate.getTime());

                Intent intent = new Intent();
                intent.putExtra("code", item);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        //CALENDARI UPDATE

        CalendarView v = new CalendarView( this );
        v = (CalendarView)findViewById(R.id.calendarView);

        v.setOnDateChangeListener( new CalendarView.OnDateChangeListener() {

            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                selectedDate.set(Calendar.YEAR, year);
                selectedDate.set(Calendar.MONTH, month);
                selectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            }//met
        });
    }
}
