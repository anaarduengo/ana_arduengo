package com.example.n2w2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private MyAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private EditText mItemEdit;
    private Button mAddButton;


    private void saveData(){
        SharedPreferences sharedPreferences =getSharedPreferences("shared preferences",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mAdapter.getmDataset());
        editor.putString("task_list",json);
        editor.apply();
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task_list", null);
        Type type = new TypeToken<ArrayList<com.example.ntw.EventItem>>() {}.getType();
        List<com.example.ntw.EventItem> data=gson.fromJson(json,type);
        if (data == null) {
            mAdapter.setmDataset(new ArrayList<com.example.ntw.EventItem>());
        }
        else{
            mAdapter.setmDataset(data);
        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            com.example.ntw.EventItem code = (com.example.ntw.EventItem) data.getSerializableExtra("code");
                mAdapter.addItem(code);
        }
        if (requestCode == 2 && resultCode == RESULT_OK) {
            ItemList list = (ItemList) data.getSerializableExtra("list");
            for (int i = 0; i < list.size(); ++i){
                mAdapter.addItem(list.Acces(i));
            }
        }
        saveData();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Inventory");


        // FAB
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Main3Activity.class);
                startActivityForResult(intent, 1);
            }
        });

        // Grocery
        final Button Grocery = findViewById(R.id.R);
            Grocery.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivityForResult(intent, 2);
            }
        });

            recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
            //Cambios en el contenido no afectan al layout size del RecyclerView
        recyclerView.setHasFixedSize(true);

        //Usamos linear layout manager: Proporciona los views
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), 1));

        //Inicializamos el adapter
        mAdapter = new MyAdapter ();
        recyclerView.setAdapter(mAdapter);

        ////////////////SWIPE////////////////
        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int p = viewHolder.getAdapterPosition();
                mAdapter.remove_item(p);
                saveData();
            }
        };
        /////////////////////////////////////
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);
        loadData();
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

        private List<com.example.ntw.EventItem> mDataset;

        //Proporciona una referencia a las views de cada item de data
        //Datos complejos pueden necesitar mas de una view por item
        //Damos acceso a todos los views de un dato en un view holder
        public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView textView;
            public MyViewHolder(TextView v) {
                super(v);
                textView = v;
            }
        }
        //Proporciona un constructor
        public MyAdapter() {
            mDataset = new ArrayList<>();
        }

        public List<com.example.ntw.EventItem> getmDataset() {
            return mDataset;
        }

        //Cambia el listado entero
        public void setmDataset(List<com.example.ntw.EventItem> mDataset) {
            this.mDataset = mDataset;
            sortNewData();
            notifyDataSetChanged();
        }

        //Cambia un solo elemento
        public void addItem(com.example.ntw.EventItem newItem) {
            mDataset.add(newItem);
            sortNewData();
            notifyDataSetChanged();
        }

        public void remove_item(int pos) {
            mDataset.remove(pos);
            sortNewData();
            notifyDataSetChanged();
        }


        private void sortNewData() {
            mDataset.sort(new Comparator<com.example.ntw.EventItem>() {
                @Override
                public int compare(com.example.ntw.EventItem o1, com.example.ntw.EventItem o2) {
                    return o1.getData().compareTo(o2.getData());
                }
            });
        }

        //Crear nuevas vistas(invocado por el layout manager)
        @Override
        public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //Crear una nueva view
            TextView v = (TextView) LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.my_text_view, parent, false);

            MyViewHolder vh = new MyViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            // - get element from your dataset at this position
            // - replace the contents of the view with that element
            holder.textView.setText(mDataset.get(position).getNom());
            Calendar now = Calendar.getInstance();

            long dias =(mDataset.get(position).getData().getTime() - now.getTime().getTime())/86400000;
            if (dias <= 3)
                holder.itemView.setBackgroundColor(Color.RED);
            else if (4 <= dias && dias <= 7)
                holder.itemView.setBackgroundColor(Color.YELLOW);
            else holder.itemView.setBackgroundColor(Color.GREEN);
        }


        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return mDataset.size();
        }
    }

}