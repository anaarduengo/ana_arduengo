package com.example.ntw;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class EventItem implements Serializable {
    private String nom;
    private Date data;

    public EventItem(String nom, Date data) {
        this.nom = nom;
        this.data = data;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
}
