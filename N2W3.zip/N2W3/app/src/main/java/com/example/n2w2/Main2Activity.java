package com.example.n2w2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
   // private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private CheckboxListAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private EditText mItemEdit;
    private Button mAddButton;


    @Override
    public void onBackPressed() {}

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            com.example.ntw.EventItem code = (com.example.ntw.EventItem) data.getSerializableExtra("code");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Grocery Store");
        toolbar.setTitleTextColor(0xFFFFFFFF);

     // Inventory
        final Button Inventory = findViewById(R.id.L);
        Inventory.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Retornar llista
                finish();
            }
        });


        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        //Cambios en el contenido no afectan al layout size del RecyclerView
        recyclerView.setHasFixedSize(true);

        //Usamos linear layout manager: Proporciona los views
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), 1));

        //Inicializamos el adapter
        mAdapter = new CheckboxListAdapter();
        recyclerView.setAdapter(mAdapter);

        mItemEdit = (EditText) findViewById(R.id.item_editText);
        mAddButton = (Button) findViewById(R.id.add_button);

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = mItemEdit.getText().toString().trim();
                if (!item.isEmpty()) {
                    mAdapter.addItem(item);
                }
                mItemEdit.setText("");
            }
        });
    }

    public class CheckboxListAdapter extends RecyclerView.Adapter<CheckboxListAdapter.MyViewHolder> {

        private List<String> mDataset;
        private List<Boolean> mDatasetCheckboxes;

        //Proporciona una referencia a las views de cada item de data
        //Datos complejos pueden necesitar mas de una view por item
        //Damos acceso a todos los views de un dato en un view holder
        public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView textView;
            public CheckBox checkBox;

            public MyViewHolder(LinearLayout v) {
                super(v);
                textView = v.findViewById(R.id.textView);
                checkBox = v.findViewById(R.id.checkbox);
            }
        }
        //Proporciona un constructor
        public CheckboxListAdapter() {
            mDataset = new ArrayList<>();
        }

        //Cambia el listado entero
        public void setmDataset(List<String> mDataset) {
            this.mDataset = mDataset;
            this.mDatasetCheckboxes = new ArrayList<>(mDataset.size());
            notifyDataSetChanged();
        }

        //Cambia un solo elemento
        public void addItem(String newItem) {
            mDataset.add(newItem);
            mDatasetCheckboxes.add(false);
            notifyDataSetChanged();
        }

        public void remove_item(int pos) {
            mDataset.remove(pos);
            mDatasetCheckboxes.remove(pos);
            notifyDataSetChanged();
        }

        //Crear nuevas vistas(invocado por el layout manager)
        @Override
        public CheckboxListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            //Crear una nueva view
            LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.checkbox_adapter, parent, false);

            CheckboxListAdapter.MyViewHolder vh = new CheckboxListAdapter.MyViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(CheckboxListAdapter.MyViewHolder holder, final int position) {
            // - get element from your dataset at this position
            // - replace the contents of the view with that element
            holder.textView.setText(mDataset.get(position));
            holder.checkBox.setChecked(mDatasetCheckboxes.get(position));

            //Se activa cuando se pone una checkbox
            holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    Intent intent = new Intent(Main2Activity.this, Main4Activity.class);
                    startActivityForResult(intent, 1);
                    mDatasetCheckboxes.set(position, isChecked);
                }
            });
        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return mDataset.size();
        }

    }
}
